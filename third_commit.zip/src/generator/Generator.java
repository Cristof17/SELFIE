package generator;

public class Generator {

	private static int value =0;
	
	public static int generateInt(){
		return value++ ;
	}
	
}
